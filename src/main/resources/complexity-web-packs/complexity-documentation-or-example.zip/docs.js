/**
 * Markdown-driven documentation tabs for the Complexity Analyzer web-pack.
 * Add another object to documentation.tab.json/pages and point it to a .md file.
 */
import {marked} from "./vendor/marked.esm.js";
import DOMPurify from "./vendor/purify.es.mjs";
import hljs from "./vendor/highlight/core.min.js";
import bash from "./vendor/highlight/languages/bash.min.js";
import css from "./vendor/highlight/languages/css.min.js";
import java from "./vendor/highlight/languages/java.min.js";
import javascript from "./vendor/highlight/languages/javascript.min.js";
import json from "./vendor/highlight/languages/json.min.js";
import markdown from "./vendor/highlight/languages/markdown.min.js";
import xml from "./vendor/highlight/languages/xml.min.js";
import yaml from "./vendor/highlight/languages/yaml.min.js";

let mountController = null;

const PAGE_MANIFEST = "documentation.tab.json";
const LOGO_URL = new URL("../../icon.svg", import.meta.url).href;
const LANGUAGES = {bash, css, java, javascript, json, markdown, xml, yaml};

for (const [name, definition] of Object.entries(LANGUAGES)) {
    hljs.registerLanguage(name, definition);
}

function isValidPage(page) {
    return page
        && typeof page.id === "string"
        && /^[a-z0-9_-]+$/i.test(page.id)
        && typeof page.title === "string"
        && typeof page.file === "string"
        && page.file.endsWith(".md")
        && !page.file.startsWith("/")
        && !page.file.split(/[\\/]/).includes("..");
}

function setContentState(content, message, kind = "loading") {
    content.replaceChildren();
    const state = document.createElement("div");
    state.className = `docs-state docs-state-${kind}`;
    state.textContent = message;
    content.append(state);
}

function highlightCodeBlocks(content) {
    for (const code of content.querySelectorAll("pre > code[class*='language-']")) {
        const languageClass = [...code.classList].find(name => name.startsWith("language-"));
        const language = languageClass?.slice("language-".length).toLowerCase();
        if (!language || !hljs.getLanguage(language)) continue;

        const result = hljs.highlight(code.textContent, {language, ignoreIllegals: true});
        code.innerHTML = result.value;
        code.classList.add("hljs");
    }
}

function fixMarkdownResourceLinks(content, markdownUrl) {
    for (const link of content.querySelectorAll("a[href]")) {
        const href = link.getAttribute("href");
        if (!href || href.startsWith("#")) continue;
        if (link.getAttribute("title")?.trim().toLowerCase() === "button") {
            link.classList.add("docs-button");
            link.removeAttribute("title");
        }
        try {
            const resolved = new URL(href, markdownUrl);
            link.href = resolved.href;
            if (resolved.origin !== location.origin) {
                link.target = "_blank";
                link.rel = "noopener noreferrer";
            } else if (resolved.pathname.toLowerCase().endsWith(".zip")) {
                link.download = decodeURIComponent(resolved.pathname.split("/").pop());
            }
        } catch (ignored) {
            link.removeAttribute("href");
        }
    }

    for (const image of content.querySelectorAll("img[src]")) {
        try {
            image.src = new URL(image.getAttribute("src"), markdownUrl).href;
            image.loading = "lazy";
        } catch (ignored) {
            image.removeAttribute("src");
        }
    }
}

export function mount(root) {
    if (mountController) mountController.abort();
    mountController = new AbortController();
    const controller = mountController;

    root.innerHTML = `
        <div class="docs-app">
            <header class="docs-header">
                <div class="docs-brand">
                    <span class="docs-mark" aria-hidden="true">
                        <img class="docs-logo" src="${LOGO_URL}" alt="">
                    </span>
                    <div>
                        <div class="docs-eyebrow">COMPLEXITY ANALYZER</div>
                        <h1>Web Pack Documentation</h1>
                    </div>
                </div>
            </header>

            <nav class="docs-tabs" data-doc-tabs role="tablist" aria-label="Documentation sections"></nav>
            <main id="docs-content" class="docs-content" data-doc-content aria-live="polite">
                <div class="docs-state docs-state-loading">Loading documentation…</div>
            </main>
        </div>
    `;

    const tabs = root.querySelector("[data-doc-tabs]");
    const content = root.querySelector("[data-doc-content]");
    let requestId = 0;

    const showPage = async (page, activeButton) => {
        const currentRequest = ++requestId;
        for (const button of tabs.querySelectorAll("[role=tab]")) {
            const selected = button === activeButton;
            button.classList.toggle("active", selected);
            button.setAttribute("aria-selected", String(selected));
            button.tabIndex = selected ? 0 : -1;
        }

        content.setAttribute("aria-busy", "true");
        setContentState(content, "Loading page…");

        try {
            const markdownUrl = new URL(page.file, import.meta.url);
            const response = await fetch(markdownUrl, {signal: controller.signal});
            if (!response.ok) {
                console.error(`[WebPacks] Failed to load documentation page '${page.file}': HTTP ${response.status}`);
                content.classList.remove("docs-markdown");
                setContentState(content, `Could not load ${page.file} (HTTP ${response.status}).`, "error");
                return;
            }
            const markdown = await response.text();
            if (controller.signal.aborted || currentRequest !== requestId) return;

            const rendered = marked.parse(markdown, {gfm: true, breaks: false});
            content.innerHTML = DOMPurify.sanitize(rendered, {USE_PROFILES: {html: true}});
            content.classList.add("docs-markdown");
            fixMarkdownResourceLinks(content, markdownUrl);
            highlightCodeBlocks(content);
        } catch (error) {
            if (controller.signal.aborted || currentRequest !== requestId) return;
            console.error(`[WebPacks] Failed to load documentation page '${page.file}':`, error);
            content.classList.remove("docs-markdown");
            setContentState(content, `Could not load ${page.file}. Check its path in the pages manifest.`, "error");
        } finally {
            if (currentRequest === requestId) content.removeAttribute("aria-busy");
        }
    };

    const loadPages = async () => {
        try {
            const response = await fetch(new URL(PAGE_MANIFEST, import.meta.url), {signal: controller.signal});
            if (!response.ok) {
                console.error(`[WebPacks] Failed to load documentation manifest: HTTP ${response.status}`);
                setContentState(content, `Could not read ${PAGE_MANIFEST} (HTTP ${response.status}).`, "error");
                return;
            }
            const manifest = await response.json();
            const pages = Array.isArray(manifest.pages) ? manifest.pages.filter(isValidPage) : [];

            tabs.replaceChildren();
            if (pages.length === 0) {
                setContentState(content, "No documentation pages are configured. Add entries to the pages array.", "error");
                return;
            }

            const buttons = pages.map((page, index) => {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "docs-tab";
                button.id = `docs-tab-${index}`;
                button.setAttribute("role", "tab");
                button.setAttribute("aria-controls", "docs-content");
                button.setAttribute("aria-selected", "false");
                button.tabIndex = -1;
                button.textContent = page.title;
                button.addEventListener("click", () => void showPage(page, button));
                tabs.append(button);
                return button;
            });

            await showPage(pages[0], buttons[0]);
        } catch (error) {
            if (controller.signal.aborted) return;
            console.error("[WebPacks] Failed to load documentation manifest:", error);
            setContentState(content, "Could not read documentation.tab.json.", "error");
        }
    };

    void loadPages();
}

export function unmount(root) {
    if (mountController) {
        mountController.abort();
        mountController = null;
    }
    root.replaceChildren();
}
