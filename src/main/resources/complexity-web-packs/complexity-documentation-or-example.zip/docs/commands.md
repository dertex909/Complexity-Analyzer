# Complexity Analyzer — Command Guide

This guide covers the commands players can use to inspect the analyzer and the extra controls available to server
operators. Every command starts with `/complexity`; there is no action on the bare `/complexity` root.

Commands are registered in the mod and their output is translated for each player using the player's Minecraft language
when a translation is available. Missing translations fall back to English.

---

## Access at a glance

| Access                           | Commands                                                                                               | What they do                                                                                               |
|----------------------------------|--------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|
| **Player** — no OP required      | `analyze`, `resource`, `web url`, `web status`, `system status/stats/tps/cache info`, `geoscan status` | Read analysis, dashboard, server, and scan information.                                                    |
| **Admin** — OP level 2 or higher | All `export` commands; `web reload`; `system threads/reload/cache clear`; `geoscan start/stop/clear`   | Rebuild data, write exports, control scans, inspect worker threads, and delete analyzer cache or geo-data. |

The access check is part of each command in the mod. A server may also apply its own command restrictions.

## Quick start

| Goal                                                 | Command                                                       |
|------------------------------------------------------|---------------------------------------------------------------|
| Check how hard an item is to obtain                  | `/complexity analyze item minecraft:diamond`                  |
| Check a mob's combat rating                          | `/complexity analyze entity minecraft:warden`                 |
| Inspect a loot table                                 | `/complexity analyze loot minecraft:chests/end_city_treasure` |
| Find the analyzer's best recorded source for an item | `/complexity resource minecraft:ancient_debris`               |
| Open the web dashboard                               | `/complexity web url`                                         |
| Check whether analysis is ready                      | `/complexity system status`                                   |
| Check whether a geo-scan is running                  | `/complexity geoscan status`                                  |

## Reading command syntax

| Notation                                      | Meaning                                                                                                            |
|-----------------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| `<item_id>`, `<entity_id>`, `<loot_table_id>` | Replace the placeholder with a Minecraft resource ID, such as `minecraft:diamond`. Do not type the angle brackets. |
| `[chunks]`, `[force]`                         | Optional arguments. If omitted, the command uses the default shown below.                                          |
| Press **Tab**                                 | Ask Minecraft to suggest valid IDs, formats, categories, profiles, or cache names for the current argument.        |

Use the full namespace when in doubt: `minecraft:diamond` is clearer than `diamond`. Item and entity suggestions come
from the loaded registries; loot-table suggestions come from the loot data available to the analyzer.

---

## Player commands

### Analyze items, entities, and loot

| Command                                    | What you get                                                                                                                                                                |
|--------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `/complexity analyze item <item_id>`       | Complexity score and category; whether the item has a recipe; recipe depth and recipe usage count; and recorded alternative acquisition sources, ordered by estimated cost. |
| `/complexity analyze entity <entity_id>`   | Entity category, health, attack, armor, calculated combat factors, difficulty rating, and notable drops with estimated average yield per kill.                              |
| `/complexity analyze loot <loot_table_id>` | Recorded items for a loot table, the source type, average/highest/lowest recorded chance, and drops grouped into chance bands.                                              |

Examples:

~~~text
/complexity analyze item minecraft:netherite_ingot
/complexity analyze entity minecraft:warden
/complexity analyze loot minecraft:chests/end_city_treasure
~~~

The analysis engine must be ready for these reports. Check `/complexity system status` and wait for `READY` if analysis
is still running. Entity reports only work for entities the mod can analyze as living mobs. Loot reports need the loot
source data to be initialized; an empty result can mean the table has no recorded drops or has not been cached.

### Understand an item score

The score is the analyzer's calculated complexity value: a lower finite score means the mod's model considers the item
less complex to obtain. Ordinary category thresholds increase by powers of ten. The category is a band, not a vanilla
Minecraft attribute.

| Category    |                                              Score range | Category      |                                           Score range |
|-------------|---------------------------------------------------------:|---------------|------------------------------------------------------:|
| Absolute    |                                                      `0` | Trivial       |                                      `0 < score ≤ 10` |
| Simple      |                                       `10 < score ≤ 100` | Moderate      |                                 `100 < score ≤ 1,000` |
| Complex     |                                 `1,000 < score ≤ 10,000` | Difficult     |                            `10,000 < score ≤ 100,000` |
| Expert      |                            `100,000 < score ≤ 1,000,000` | Master        |                      `1,000,000 < score ≤ 10,000,000` |
| Mythical    |                       `10,000,000 < score ≤ 100,000,000` | Transcendent  |                 `100,000,000 < score ≤ 1,000,000,000` |
| Celestial   |                 `1,000,000,000 < score ≤ 10,000,000,000` | Astral        |            `10,000,000,000 < score ≤ 100,000,000,000` |
| Eternal     |            `100,000,000,000 < score ≤ 1,000,000,000,000` | Primordial    |      `1,000,000,000,000 < score ≤ 10,000,000,000,000` |
| Singularity |       `10,000,000,000,000 < score ≤ 100,000,000,000,000` | Inconceivable | `100,000,000,000,000 < score ≤ 1,000,000,000,000,000` |
| Boundless   | `1,000,000,000,000,000 < score ≤ 10,000,000,000,000,000` |               |                                                       |

| Special result   | Meaning                                                       |
|------------------|---------------------------------------------------------------|
| **Unobtainable** | The cost is infinite or above the highest defined score band. |
| **Uncalculable** | The analyzer could not produce a valid score.                 |

The report's source section explains recipe depth and how many recipes use the item. Alternative sources are separate
ways the analyzer has recorded to obtain it; their displayed estimated cost includes the source's base factor and the
complexity of required inputs.

Mob ratings use the mod's registered boss flags first. Other mobs are rated by calculated combat power:

| Rating           | Assignment rule                                                 |
|------------------|-----------------------------------------------------------------|
| Boss / Mini-boss | Explicitly marked as a boss or mini-boss in the mod's mob data. |
| Extreme          | Combat power is greater than `500`.                             |
| Hard             | Greater than `200` and up to `500`.                             |
| Medium           | Greater than `100` and up to `200`.                             |
| Easy             | Greater than `50` and up to `100`.                              |
| Trivial          | `50` or lower.                                                  |

The mod calculates survivability as `max health × (1 + armor × 0.04)`, threat as `1 + ln(1 + attack damage)`, and combat
power as survivability × threat. These are mod ratings, not vanilla stats; the report also shows the base stats used.

Loot drops are grouped by their recorded chance:

| Rarity label |                    Recorded chance |
|--------------|-----------------------------------:|
| Common       |                 Greater than `20%` |
| Uncommon     | Greater than `10%` and up to `20%` |
| Rare         |  Greater than `5%` and up to `10%` |
| Very Rare    |   Greater than `1%` and up to `5%` |
| Legendary    |                      `1%` or lower |

These bands describe the chance data collected by the analyzer; the command does not simulate a fresh loot roll.

### Find a base resource

`/complexity resource <item_id>` reports the recorded base-resource route with the lowest base factor for that item. It
shows the source type and details, base factor and difficulty band, required source items, and their amounts. If the
item also has a recipe, the output includes a clickable link to its full item analysis.

If the command says no base-resource data is available, the analyzer has no recorded raw acquisition route for that
item. This can happen when the item is only available through crafting or the relevant source data is unavailable.

~~~text
/complexity resource minecraft:iron_ingot
~~~

### Open or check the web dashboard

| Command                    | What happens                                                                                                                                            |
|----------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| `/complexity web url`      | Shows a clickable **Open in Browser** link.                                                                                                             |
| `/complexity web url link` | Shows the clickable URL as text, which is useful when you need to copy or read the address.                                                             |
| `/complexity web status`   | Shows backend state, visitor count, data snapshot age, and item, mob, and recipe counts when a snapshot exists. It also reports the last error, if any. |

If `web url` says the dashboard is inactive, check the server's `web_server.port` setting. A value of `-1` disables the
dashboard. In single-player with port `0`, open the world to LAN first. If the URL uses `127.0.0.1`, it points back to
the server machine; remote players need the server's reachable address configured.

### Check engine and server status

| Command                         | Available to | What it reports                                                                                                       |
|---------------------------------|--------------|-----------------------------------------------------------------------------------------------------------------------|
| `/complexity system status`     | Player       | Engine state — `READY`, `ANALYZING`, `FAILED`, or `IDLE` — and item, recipe, and base-resource totals when available. |
| `/complexity system stats`      | Player       | Detailed item, recipe, and base-resource counts. Requires the engine to be ready.                                     |
| `/complexity system tps`        | Player       | Current TPS and MSPT estimate, plus JVM heap memory used and maximum.                                                 |
| `/complexity system cache info` | Player       | Whether caching is enabled and whether each analyzer cache file exists, with its size and age when present.           |

`READY` means reports can use the completed analysis data. During `ANALYZING`, wait before retrying an analysis or
export. `FAILED` means the engine did not complete successfully; an admin may need to inspect the server log.

### Check geo-scan status

`/complexity geoscan status` is available to everyone. While a scan is active, it reports progress, scanned and target
chunk counts, speed, elapsed time, and the MSPT throttle state for profiles that use an MSPT limit. Hover the
biome-details hint in chat for per-biome progress. While a scan is scheduled, the status shows its countdown.

---

## Admin commands

### System maintenance

| Command                                     | What it does                                                                                                  | Caution                                                       |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------|
| `/complexity system threads`                | Shows compute-pool parallelism, active worker count, and queued background tasks.                             | Diagnostic only.                                              |
| `/complexity system reload`                 | Starts a full analysis-engine reload in the background and announces it to players.                           | Can cause noticeable lag while analysis is rebuilt.           |
| `/complexity system cache clear`            | Deletes all analyzer cache files for the loaded world. The response offers a clickable engine-reload command. | Deletes cache files; it does not clear the geo-scan database. |
| `/complexity system cache clear <cache_id>` | Deletes only the selected analyzer cache file.                                                                | Use the exact ID from the table below.                        |

Cache IDs accepted by `cache clear`:

| Cache ID           | Cached data               |
|--------------------|---------------------------|
| `recipe_graph`     | Recipe graph              |
| `machine_registry` | Machine registry          |
| `block_break`      | Block-break resource data |
| `universal_loot`   | Loot-table resource data  |
| `farming`          | Farming resource data     |
| `mob_drop`         | Mob-drop resource data    |

Clearing a cache removes only that cached analyzer data. Run `/complexity system reload` to rebuild immediately;
otherwise the analyzer rebuilds the relevant cache when it next starts analysis. Cache files are stored with the current
world's analyzer data under `<world>/data/complexityanalyzer/`.

### Rebuild dashboard data

`/complexity web reload` rebuilds the dashboard's data snapshot asynchronously from the current engine state. It
requires OP level 2 and a ready engine. The command reports when the background rebuild finishes or if it fails.

### Export reports to JSON or CSV

The entire `export` command group requires OP level 2. Built-in formats are `json` and `csv`; press Tab after `items` or
`mobs` to see the registered formats.

| Command                                                      | Contents                                                                           |
|--------------------------------------------------------------|------------------------------------------------------------------------------------|
| `/complexity export items <format> all`                      | All analyzed items.                                                                |
| `/complexity export items <format> category <category_name>` | Items in one complexity category, such as `Mythical`.                              |
| `/complexity export items <format> top <count>`              | Up to `count` items, sorted from highest complexity down. `count` must be 1–1000.  |
| `/complexity export items <format> single <item_id>`         | One item's detailed export.                                                        |
| `/complexity export mobs <format> all`                       | All recognized, analyzable mobs.                                                   |
| `/complexity export mobs <format> category <category_name>`  | Mobs in a vanilla mob category, such as `monster`.                                 |
| `/complexity export mobs <format> top <count>`               | Up to `count` mobs, sorted from highest combat power down. `count` must be 1–1000. |
| `/complexity export mobs <format> single <mob_id>`           | One mob's detailed export.                                                         |

Examples:

~~~text
/complexity export items json top 25
/complexity export mobs csv single minecraft:warden
~~~

Exports run in background worker threads. They are written under the current world's `data/complexityanalyzer/export/`
directory. The completion message shows the output filename; admins also receive a completion notice. Item top exports
omit infinite complexity scores; mob exports include only analyzable mobs with finite combat power.

The item category argument uses the category names in the score table above. The mob category argument uses Minecraft's
mob-category names; it is not the same as an item complexity category.

### Start, stop, and clear geo-scans

Geo-scans inspect world chunks and collect geo-data about where resources generate. Starting, stopping, and clearing
scans require OP level 2; status is public.

| Command                                                | What it does                                                                       |
|--------------------------------------------------------|------------------------------------------------------------------------------------|
| `/complexity geoscan start`                            | Opens a clickable profile menu and prints usage examples.                          |
| `/complexity geoscan start <profile> [chunks] [force]` | Schedules a scan, or starts it immediately when `force` is `true`.                 |
| `/complexity geoscan stop`                             | Stops the active scan or cancels its countdown.                                    |
| `/complexity geoscan status`                           | Shows current scan state and progress; available to players and admins.            |
| `/complexity geoscan clear`                            | Deletes all collected geo-data. Cannot be run while a scan or countdown is active. |

| Profile      | MSPT threshold in the code | When to choose it                                          |
|--------------|---------------------------:|------------------------------------------------------------|
| `normal`     |                         30 | Most conservative configured MSPT threshold.               |
| `fast`       |                         40 | Faster progress with a higher tick-time threshold.         |
| `aggressive` |                         50 | Higher scan pressure; use when the server can tolerate it. |
| `unlimited`  |    No automatic MSPT limit | Fastest, with the highest risk of server lag.              |

The thresholds control scan throttling; they are not a promise that the server will stay below that MSPT. The menu shown
by `geoscan start` displays the profile limits.

| Argument  | Requirement / default / range                            | Meaning                                                                                                   |
|-----------|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|
| `profile` | Required: `normal`, `fast`, `aggressive`, or `unlimited` | Scan profile. Tab suggests the valid names.                                                               |
| `chunks`  | Default `32`; range `1–2,147,483,647`                    | Target number of pristine chunks to find per biome. Larger targets take longer.                           |
| `force`   | Default `false`; use `true` or `false`                   | `false` schedules the scan with a 60-second countdown. `true` skips the countdown and starts immediately. |

Examples:

~~~text
/complexity geoscan start
/complexity geoscan start normal
/complexity geoscan start fast 64
/complexity geoscan start normal 32 true
/complexity geoscan status
~~~

If a scan is already active or scheduled, another `start` is rejected; run `stop` first. A forced start broadcasts a
warning. `aggressive` and `unlimited` force-starts receive the strongest warning. Use `clear` only when you intend to
permanently erase the collected geo-data; it cannot run during a scan or countdown.

---

## Troubleshooting

| Message or symptom                   | What to check                                                                                                                 |
|--------------------------------------|-------------------------------------------------------------------------------------------------------------------------------|
| Analysis engine is not ready         | Run `/complexity system status`. Wait for `READY` before item, entity, loot, resource, export, or dashboard-reload commands.  |
| Item or entity not found             | Use the full namespaced ID and Tab completion, for example `minecraft:diamond`.                                               |
| Loot analysis returns no items       | Confirm the loot source is enabled and initialized; the table may be empty or its data may not have been cached.              |
| Dashboard URL is unavailable         | Check `web_server.port`; `-1` disables the dashboard. In single-player with port `0`, use **Open to LAN**.                    |
| Cache has not been built             | This is normal before the related analysis runs. Run an engine reload if you need to rebuild it now.                          |
| Geo-scan says one is already running | Use `/complexity geoscan status` to check it. An admin can stop the active scan or countdown with `/complexity geoscan stop`. |

