# Complexity Analyzer Web Pack Development Guide

A **web pack** is a directory or ZIP archive that registers one or more browser tabs in the Complexity Analyzer viewer.
Each tab is described by a JSON manifest and implemented as a browser ES module. Optional styles and other resources are
served from the same pack namespace.

This guide is itself implemented as a web pack, so it doubles as a working example. Download it below to inspect the
implementation: a small web-pack ouroboros, with more JSON and considerably fewer snakes.

[Download this guide as a web pack](../complexity-documentation-or-example.zip "button")

## 1. Quick start

Create this directory structure:

```text
my-pack/
├── my-pack.tab.json
├── js/
│   └── tab.js
├── css/
│   └── tab.css
└── assets/
    └── icon.svg
```

The manifest must be directly inside the pack root. Its filename must end in `.tab.json`; `my-pack.tab.json` is a
conventional name.

Create `my-pack.tab.json`:

```json
{
  "id": "example-tab",
  "namespace": "example-mod",
  "title": "Example",
  "entrypoint": "js/tab.js",
  "styles": [
    "css/tab.css"
  ],
  "order": 100
}
```

Create `js/tab.js`:

```js
export function mount(root, context) {
    const heading = document.createElement("h1");
    heading.textContent = "Example web-pack tab";

    const icon = document.createElement("img");
    icon.alt = "Example icon";
    icon.src = new URL("../assets/icon.svg", import.meta.url).href;

    root.replaceChildren(heading, icon);
}

export function unmount(root, context) {
    root.replaceChildren();
}
```

Create `css/tab.css`:

```css
:host {
    display: block;
    height: 100%;
}

h1 {
    color: var(--text-bright, #ffffff);
}
```

After placing the pack in a supported location, start the server. The scanner reads the manifest, registers the tab, and
serves the module and its resources under the declared namespace.

## 2. Pack locations and deployment

Use directory packs or ZIP archives depending on your workflow. Both unpacked folders and `.zip` archives are fully
supported across all locations: in dev resources, in the external runtime directory, and bundled inside mod JARs.

### 2.1 Development source directory

In a development workspace, place directory packs or ZIP archives here:

```text
<project-root>/src/main/resources/complexity-web-packs/
```

For an unpacked directory pack:

```text
<project-root>/src/main/resources/complexity-web-packs/my-pack/
├── my-pack.tab.json
├── js/tab.js
├── css/tab.css
└── assets/icon.svg
```

For a pre-packaged ZIP archive:

```text
<project-root>/src/main/resources/complexity-web-packs/my-pack.zip
```

The development scanner discovers both directories and ZIP archives in this resource directory. The web development
watcher also monitors it recursively, so changes to manifests, modules, styles, and assets trigger an automatic viewer
reload. The development project root is located relative to the process working directory; the scanner checks that
directory and up to two parent directories for `src/main/resources/`.

### 2.2 External development or server packs

The standard external pack directory is relative to the server's working directory:

```text
run/complexity-web-packs/
```

Place directory packs or ZIP archives directly inside it:

```text
run/complexity-web-packs/my-pack/my-pack.tab.json
run/complexity-web-packs/my-pack.zip
```

The scanner selects `run/complexity-web-packs/` when that directory exists. If it does not exist but a root-level
`complexity-web-packs/` directory does, the root-level directory is used. If neither exists, the application creates the
pack directory under `run/` when `run/` exists; otherwise it creates `complexity-web-packs/` at the working-directory
root.

The selected external directory is watched recursively. You can add, edit, rename, or delete pack files while the server
is running. If both external locations exist, `run/complexity-web-packs/` takes precedence as the active external
directory.

### 2.3 Distribution in an add-on mod JAR

For distribution inside a mod JAR (including add-ons or Complexity Analyzer itself), place directory packs or `.zip`
archives under resources:

```text
<mod-project>/src/main/resources/complexity-web-packs/<pack-directory>/
# or
<mod-project>/src/main/resources/complexity-web-packs/<pack-name>.zip
```

The built JAR will contain the corresponding path:

```text
complexity-web-packs/<pack-directory>/<manifest-and-resources>
# or
complexity-web-packs/<pack-name>.zip
```

The loader examines the `complexity-web-packs/` resource directory of loaded mods and discovers both child directories
and root-level `.zip` archives. The manifest must be at the root of each child directory or archive. This discovery
occurs during server initialization. Resources inside a JAR are static: rebuild and replace the JAR, then restart the
server to publish changes.

### 2.4 ZIP packs on disk

Place a ZIP file directly in any supported pack directory (such as `run/complexity-web-packs/my-pack.zip`).

The archive must have the manifest and resource files at its root. Do not wrap them in an additional top-level folder:

```text
my-pack.zip
├── my-pack.tab.json
├── js/tab.js
├── css/tab.css
└── assets/icon.svg
```

The scanner accepts root-level files whose names end in `.tab.json`. Files in nested directories are resources, but
nested manifests are not discovered. A ZIP may contain multiple root-level manifests; each valid manifest registers a
tab. For a simple pack, use one manifest per directory or archive.

At scan time, the ZIP is read into memory and its file handle is closed. Its resource files are then served from the
in-memory archive. In a watched filesystem directory, replacing or editing the ZIP invalidates the pack registry and
causes the browser viewer to reload.

## 3. Manifest reference

Manifests are UTF-8 JSON files placed at the pack root. The filename must end with the exact, lowercase suffix
`.tab.json`.

```json
{
  "id": "example-tab",
  "namespace": "example-mod",
  "title": "Example tab",
  "entrypoint": "js/tab.js",
  "styles": [
    "css/tab.css"
  ],
  "order": 100,
  "subtabs": [
    {
      "id": "overview",
      "title": "Overview"
    },
    {
      "id": "details",
      "title": "Details"
    }
  ],
  "mimeTypes": {
    ".wasm": "application/wasm",
    ".md": "text/markdown; charset=UTF-8"
  }
}
```

| Property     | Type             | Required            | Meaning                                                                                                                                                                                                                                                             |
|--------------|------------------|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `id`         | string           | No, but recommended | Unique tab identifier across all discovered packs. Defaults to the normalized namespace. If two manifests use the same ID, the first discovered tab is retained and later duplicates are ignored.                                                                   |
| `namespace`  | string           | No, but recommended | URL namespace for this pack's resources. Defaults to the pack directory name or, for a filesystem ZIP, the archive filename without `.zip`. It is normalized to lowercase; characters outside `a-z`, `0-9`, `_`, and `-` become `_`. Use an explicit, unique value. |
| `title`      | string           | No                  | Text displayed for the tab in the viewer. Defaults to `id`.                                                                                                                                                                                                         |
| `entrypoint` | string           | Yes                 | Path to the tab's ES module, relative to the pack root. The loader generates the browser URL from this path.                                                                                                                                                        |
| `styles`     | array of strings | No                  | CSS paths relative to the pack root. Each stylesheet is loaded into the tab's Shadow DOM.                                                                                                                                                                           |
| `order`      | integer          | No                  | Position among custom tabs. Lower values appear first. Defaults to `100`.                                                                                                                                                                                           |
| `subtabs`    | array            | No                  | Static subtab definitions. Each entry may be a string or an object with `id` and `title` strings.                                                                                                                                                                   |
| `mimeTypes`  | object           | No                  | Additional MIME type mappings for this namespace. Keys are file extensions; values are MIME type strings. See [MIME types](#7-mime-types).                                                                                                                          |

Use forward slashes in all manifest paths, including when developing on Windows. Paths are relative to the pack root; do
not use absolute filesystem paths or `..` path segments.

The scanner applies these defaults: `namespace` from the pack location, `id` from `namespace`, `title` from `id`, and
`order` as `100`. An `entrypoint` is still required for a usable tab. Invalid JSON or malformed manifests are skipped
and reported in the server log.

### Multiple tabs in one pack

A directory pack can contain more than one root-level `*.tab.json` manifest. Every manifest can use a different `id` and
`title`. They may share one `namespace` when their files are part of the same resource set. When manifests share a
namespace, declare consistent MIME mappings and keep resource paths unambiguous.

## 4. Tab module and lifecycle

The `entrypoint` is loaded by the browser as an ES module. The recommended interface uses named exports:

```js
export function mount(root, context) {
    const panel = document.createElement("section");
    const heading = document.createElement("h1");
    heading.textContent = "Example tab";
    panel.append(heading);
    root.replaceChildren(panel);
}

export function unmount(root, context) {
    root.replaceChildren();
}
```

`mount(root, context)` runs when the viewer renders the custom tab. `root` is the tab's content element inside a Shadow
DOM. Put the tab's DOM under this element rather than replacing the viewer document. Use `unmount(root, context)` to
remove event listeners, timers, subscriptions, and other resources when the tab is closed or another tab is selected.

The loader also accepts a default-exported object containing these handlers. As alternatives to `mount` and `unmount`,
it recognizes `onOpen(root, context)` and `onClose(root, context)`. An optional
`onSubTabChange(subTabId, root, context)`
handler is called when the active custom tab's subtab changes.

The `context` object exposes the following integration points:

| Member                          | Purpose                                                                                                                              |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
| `context.db`                    | Currently loaded analyzer data.                                                                                                      |
| `context.state`                 | Current viewer state.                                                                                                                |
| `context.token`                 | Server URL token used by the viewer. Prefer module-relative URLs for pack resources instead of constructing tokenized URLs manually. |
| `context.store`                 | Viewer event store. It emits a `change` event.                                                                                       |
| `context.subTab`                | Getter for the current subtab ID.                                                                                                    |
| `context.setSubTabs(list)`      | Set dynamic subtabs. Entries may be strings or `{ id, title }` objects.                                                              |
| `context.navigate(id, subTab?)` | Navigate to a viewer tab and, optionally, a subtab.                                                                                  |
| `context.navigateSub(id)`       | Navigate to a subtab.                                                                                                                |
| `context.selectItem(index)`     | Select an item by its viewer index.                                                                                                  |
| `context.selectMob(index)`      | Select a mob by its viewer index.                                                                                                    |

The schema of `context.db` and `context.state` is defined by the analyzer implementation and is outside the web-pack
file format. Avoid depending on undocumented object fields when a public helper in `context` is available.

## 5. Subtabs

Static subtabs can be declared in the manifest:

```json
"subtabs": [
  {
    "id": "overview",
    "title": "Overview"
  },
  {
    "id": "settings",
    "title": "Settings"
  }
]
```

String entries use the same value as both ID and title:

```json
"subtabs": [
  "overview",
  "settings"
]
```

For dynamic subtabs, call `context.setSubTabs` from the module:

```js
context.setSubTabs([
    {id: "overview", title: "Overview"},
    {id: "settings", title: "Settings"}
]);
```

Use stable IDs for navigation and state. Titles are presentation text. When the list is empty or omitted, the viewer
displays no subtabs for the custom tab.

## 6. Resource URLs and styles

All pack files are served from the namespace route:

```text
/<server-token>/u/<namespace>/<path-within-pack>
```

For example, a module at `js/tab.js` in namespace `example-mod` is served under a route equivalent to:

```text
/<server-token>/u/example-mod/js/tab.js
```

The server token is generated or configured by the viewer. Do not hard-code the complete route. `entrypoint` and
`styles`
paths are converted into route URLs automatically.

Resolve module-relative assets from `import.meta.url`:

```js
const iconUrl = new URL("../assets/icon.svg", import.meta.url);
image.src = iconUrl.href;

const dataUrl = new URL("../assets/data.json", import.meta.url);
const response = await fetch(dataUrl);
```

In CSS, use paths relative to the CSS file:

```css
.banner {
    background-image: url("../assets/banner.png");
}
```

The tab has a Shadow DOM boundary. The CSS files listed in `styles` are attached inside it, so their selectors apply to
the tab rather than the rest of the viewer. Use `:host` when styling the custom tab host. CSS custom properties
inherited from the viewer can be used for consistent colors and typography.

The HTTP handler rejects request paths containing `..`, repeated slashes, backslashes, colons, or null characters.
Resolve assets relative to their module or stylesheet and keep them inside the pack namespace.

## 7. MIME types

The server has the following built-in MIME mappings:

| Extensions      | MIME type                        |
|-----------------|----------------------------------|
| `.html`         | `text/html; charset=UTF-8`       |
| `.js`, `.mjs`   | `text/javascript; charset=UTF-8` |
| `.css`          | `text/css; charset=UTF-8`        |
| `.wasm`         | `application/wasm`               |
| `.json`         | `application/json`               |
| `.xml`          | `application/xml; charset=UTF-8` |
| `.txt`          | `text/plain; charset=UTF-8`      |
| `.csv`          | `text/csv; charset=UTF-8`        |
| `.yml`, `.yaml` | `text/yaml; charset=UTF-8`       |
| `.ico`          | `image/x-icon`                   |
| `.png`          | `image/png`                      |
| `.jpg`, `.jpeg` | `image/jpeg`                     |
| `.svg`          | `image/svg+xml`                  |
| `.webp`         | `image/webp`                     |
| `.gif`          | `image/gif`                      |
| `.woff2`        | `font/woff2`                     |
| `.woff`         | `font/woff`                      |
| `.ttf`          | `font/ttf`                       |
| `.otf`          | `font/otf`                       |
| `.ogg`          | `audio/ogg`                      |
| `.mp3`          | `audio/mpeg`                     |
| `.wav`          | `audio/wav`                      |
| `.gltf`         | `model/gltf+json`                |
| `.glb`          | `model/gltf-binary`              |
| `.zip`          | `application/zip`                |

Unknown extensions are served as `application/octet-stream`.

Declare a custom mapping in the manifest when a resource needs a different or otherwise unknown content type:

```json
"mimeTypes": {
  ".md": "text/markdown; charset=UTF-8",
  ".gltf": "model/gltf+json",
  ".wasm": "application/wasm"
}
```

Extensions are case-insensitive and may be written with or without a leading dot. The resolver uses the longest matching
extension, which supports compound suffixes. Custom mappings apply only to the manifest's namespace and take precedence
over built-in mappings. If multiple tabs declare conflicting values for the same extension in one namespace, the first
registered value is kept and a warning is logged.

## 8. Hot reload

Hot reload is available for filesystem resources while the development server is running. The watcher monitors these
pack locations recursively:

```text
<project-root>/src/main/resources/complexity-web-packs/
<server-working-directory>/run/complexity-web-packs/
```

If the active external directory is the root-level fallback, the watcher monitors:

```text
<server-working-directory>/complexity-web-packs/
```

The watcher handles file and directory creation, modification, and deletion. When a new directory is created, its
existing descendants are registered recursively. After filesystem events have been quiet for 250 ms, the server
invalidates its web-resource registry and broadcasts a reload event to connected viewers. This covers changes to
manifests, JavaScript, CSS, images, other pack resources, and filesystem ZIP archives.

Keep the browser viewer open and connected to the server to see automatic reloads. If a change is not reflected, confirm
that the edited file is inside one of the watched locations and inspect the server log for watcher or manifest errors.

Hot reload does not apply to resources inside a built mod JAR. Rebuild the add-on, replace its JAR, and restart the
server. The viewer's core UI has its own development source path; it is separate from web-pack directories.

## 9. Discovery order and identifiers

The registry scans sources in this order: the active external pack directory, the development resource directory when
present, and resource directories from other loaded mods. Custom tabs are then sorted by ascending `order`.

Tab IDs are unique across the complete registry. If duplicate IDs are found, the first discovered definition is used.
Namespaces identify resource routes; avoid namespace reuse across mods. Namespace collisions are merged to permit
resource lookup, which can make duplicate resource paths ambiguous. Assign every independently distributed pack a unique
namespace and every tab a unique ID.

Entries whose filename begins with `.` are ignored in filesystem pack roots. Directory packs and ZIP files must be
placed directly in the active external pack directory; the scanner does not search arbitrary nested folders for pack
containers.

## 10. Troubleshooting

| Symptom                                                          | Check                                                                                                                                                                                                                                               |
|------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| The tab does not appear                                          | Confirm that the pack is directly under an active pack root, the manifest is at the pack root, its filename ends in `.tab.json`, and the JSON is valid. Confirm that `entrypoint` names an existing module and that `id` is not already registered. |
| The tab appears but its module fails                             | Check the browser console and server log. Verify the `entrypoint` path and ES-module syntax. Confirm that imports use valid relative URLs and that imported files exist in the pack.                                                                |
| A stylesheet or image returns 404                                | Check the path relative to the pack root in `styles`, or relative to the importing module/CSS file for assets. Preserve exact filename case and do not include a containing ZIP folder prefix.                                                      |
| JavaScript, JSON, or another resource is interpreted incorrectly | Check the response MIME type. Declare an appropriate `mimeTypes` entry for the namespace if the extension is not built in or requires a custom value.                                                                                               |
| Disk changes do not reload the viewer                            | Confirm that the file is under the watched development resources or active external pack directory. JAR resources are static and require a server restart after rebuilding.                                                                         |
| A filesystem ZIP cannot be updated                               | The scanner reads the archive into memory and closes the file after scanning. Ensure the ZIP is in the active external directory and that the watcher reports the replacement event.                                                                |
